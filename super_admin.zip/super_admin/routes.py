from flask import render_template, request, session, jsonify, url_for, redirect, Blueprint
from models import get_connection, create_user
from datetime import datetime

superadmin_bp = Blueprint("super_admin", __name__, template_folder="templates")

# ------------------------------
# Dashboard
# ------------------------------
@superadmin_bp.route("/dashboard")
def dashboard():
    if session.get("user_role") != "super_admin":
        return redirect(url_for("home"))
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    # Total Admins
    cursor.execute("SELECT COUNT(*) as total FROM users WHERE role='admin'")
    total_admins = cursor.fetchone()['total']

    # Total Trainers
    cursor.execute("SELECT COUNT(*) as total FROM users WHERE role='trainer'")
    total_trainers = cursor.fetchone()['total']

    # Total Courses
    cursor.execute("SELECT COUNT(*) as total FROM courses")
    total_courses = cursor.fetchone()['total']

    
    # Active Courses
    cursor.execute("SELECT COUNT(*) as total FROM courses WHERE is_active=1")
    active_courses = cursor.fetchone()['total']

    

    

    cursor.close()
    conn.close()

    return render_template(
        "dashboard.html",
        total_admins=total_admins,
        total_trainers=total_trainers,
        total_courses=total_courses,
        active_courses=active_courses,       
       
    )



# ------------------------------
# Admin Management
# ------------------------------
@superadmin_bp.route('/admins')
def admins():
    if session.get("user_role") != "super_admin":
        return redirect(url_for("home"))
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '', type=str).strip()
    per_page = 10
    offset = (page - 1) * per_page

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    if search:
        search_like = f"%{search}%"
        cursor.execute(
            "SELECT user_id, email, full_name, phone, role, is_active FROM users WHERE role='admin' AND full_name LIKE %s ORDER BY user_id DESC LIMIT %s OFFSET %s",
            (search_like, per_page, offset)
        )
        admins = cursor.fetchall()
        cursor.execute("SELECT COUNT(*) AS total FROM users WHERE role='admin' AND full_name LIKE %s", (search_like,))
    else:
        cursor.execute(
            "SELECT user_id, email, full_name, phone, role, is_active FROM users WHERE role='admin' ORDER BY user_id DESC LIMIT %s OFFSET %s",
            (per_page, offset)
        )
        admins = cursor.fetchall()
        cursor.execute("SELECT COUNT(*) AS total FROM users WHERE role='admin'")
    total = cursor.fetchone()['total']
    cursor.close()
    conn.close()

    total_pages = (total + per_page - 1) // per_page

    return render_template(
        "admins.html",
        admins=admins,
        page=page,
        total_pages=total_pages,
        search=search
    )


@superadmin_bp.route('/admins/add', methods=["GET"])
def add_admin_page():
    if session.get("user_role") != "super_admin":
        return redirect(url_for("home"))
    return render_template("add_admin.html")


@superadmin_bp.route("/admins/add", methods=["POST"])
def add_admin():
    if session.get("user_role") != "super_admin":
        return jsonify({"success": False, "error": "Unauthorized"}), 403
    full_name = request.form.get("full_name")
    email = request.form.get("email")
    role = request.form.get("role", "admin")
    phone = request.form.get("phone")
    is_active = request.form.get("is_active", 'True') == 'True'
    if not all([full_name, email, role]):
        return jsonify({"success": False, "error": "Missing required fields."})
    try:
        user_id, plain_password = create_user(
            full_name=full_name,
            email=email,
            role=role,
            phone=phone,
            is_active=is_active
        )
        return jsonify({
            "success": True,
            "user": {
                "user_id": user_id,
                "full_name": full_name,
                "email": email,
                "phone": phone,
                "role": role,
                "is_active": is_active,
                "password": plain_password
            }
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


# Toggle Admin Status
@superadmin_bp.route("/toggle_admin_status/<int:user_id>", methods=["POST"])
def toggle_admin_status(user_id):
    data = request.get_json()
    new_status = bool(int(data.get("is_active", 0)))
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET is_active = %s WHERE user_id = %s", (new_status, user_id))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({"success": True})


@superadmin_bp.route("/admins/edit/<int:user_id>", methods=["GET"])
def edit_admin_page(user_id):
    if session.get("user_role") != "super_admin":
        return redirect(url_for("home"))
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT user_id, full_name, email, phone, role, is_active FROM users WHERE user_id=%s", (user_id,))
    admin = cursor.fetchone()
    cursor.close()
    conn.close()
    if not admin:
        return "Admin not found", 404
    return render_template("edit_admin.html", admin=admin)


@superadmin_bp.route("/admins/edit/<int:user_id>", methods=["POST"])
def edit_admin_post(user_id):
    full_name = request.form.get("full_name")
    email = request.form.get("email")
    phone = request.form.get("phone")
    is_active = request.form.get("is_active", 'True') == 'True'
    if not all([full_name, email]):
        return "Missing required fields", 400
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE users SET full_name=%s, email=%s, phone=%s, is_active=%s WHERE user_id=%s
    """, (full_name, email, phone, is_active, user_id))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for("super_admin.admins"))


@superadmin_bp.route("/admins/delete/<int:user_id>", methods=["GET"])
def delete_admin(user_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM users WHERE user_id=%s", (user_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for("super_admin.admins"))



# ------------------------------
# Course Management
# ------------------------------
@superadmin_bp.route('/courses')
def courses():
    if session.get('user_role') != 'super_admin':
        return redirect(url_for('auth.login'))

    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '', type=str).strip()
    per_page = 10
    offset = (page - 1) * per_page

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    if search:
        search_like = f"%{search}%"
        cursor.execute(
            "SELECT * FROM courses WHERE course_name LIKE %s ORDER BY course_id DESC LIMIT %s OFFSET %s",
            (search_like, per_page, offset)
        )
        courses = cursor.fetchall()
        cursor.execute("SELECT COUNT(*) AS total FROM courses WHERE course_name LIKE %s", (search_like,))
    else:
        cursor.execute(
            "SELECT * FROM courses ORDER BY course_id DESC LIMIT %s OFFSET %s",
            (per_page, offset)
        )
        courses = cursor.fetchall()
        cursor.execute("SELECT COUNT(*) AS total FROM courses")
    total = cursor.fetchone()['total']
    conn.close()

    total_pages = (total + per_page - 1) // per_page

    return render_template(
        'courses.html',
        courses=courses,
        page=page,
        total_pages=total_pages,
        search=search
    )


@superadmin_bp.route('/add_course', methods=['GET'])
def show_add_course():
    if session.get('user_role') != 'super_admin':
        return redirect(url_for('auth.login'))
    return render_template('add_course.html')


@superadmin_bp.route('/add_course', methods=['POST'])
def add_course():
    if session.get('user_role') != 'super_admin':
        return jsonify({'success': False, 'error': 'Unauthorized'}), 403

    course_name = request.form.get('course_name')
    status = request.form.get('status')
    description = request.form.get('description', '')
    duration_weeks = request.form.get('duration_weeks', 1)
    max_leaves = request.form.get('max_leaves', 5)
    max_capacity = request.form.get('max_capacity', 30)
    start_date = request.form.get('start_date') or None
    end_date = request.form.get('end_date') or None
    is_active = True if request.form.get('is_active', '1') == '1' else False  # <-- Add this line

    if not all([course_name, status]):
        return jsonify({'success': False, 'error': 'Course name and status are required.'})

    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('''
            INSERT INTO courses
            (course_name, status, description, duration_weeks, max_leaves, max_capacity, start_date, end_date, created_by, is_active)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ''', (course_name, status, description, duration_weeks, max_leaves, max_capacity,
              start_date, end_date, session.get('user_id'), is_active))  # <-- Add is_active here
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True, 'message': 'Course added successfully!'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


# ------------------------------
# Edit Course (GET → load form)
# ------------------------------
@superadmin_bp.route("/courses/edit/<int:course_id>", methods=["GET"])
def edit_course(course_id):
    if session.get("user_role") != "super_admin":
        return redirect(url_for("auth.login"))

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM courses WHERE course_id=%s", (course_id,))
    course = cursor.fetchone()
    cursor.close()
    conn.close()

    if not course:
        return "Course not found", 404

    return render_template("edit_course.html", course=course)


# ------------------------------
# Update Course (POST → save changes)
# ------------------------------
@superadmin_bp.route("/courses/update/<int:course_id>", methods=["POST"])
def update_course(course_id):
    course_name = request.form.get("course_name")
    duration_weeks = request.form.get("duration_weeks")
    max_capacity = request.form.get("max_capacity")
    start_date = request.form.get("start_date") or None
    end_date = request.form.get("end_date") or None
    status = request.form.get("status")
    is_active = True if request.form.get("is_active") == "1" else False

    if not all([course_name, duration_weeks, max_capacity, status]):
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify({"success": False, "message": "Missing required fields."})
        return "Missing required fields", 400

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE courses 
        SET course_name=%s, duration_weeks=%s, max_capacity=%s,
            start_date=%s, end_date=%s, status=%s, is_active=%s
        WHERE course_id=%s
    """, (course_name, duration_weeks, max_capacity, start_date, end_date, status, is_active, course_id))
    conn.commit()
    cursor.close()
    conn.close()

    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"success": True, "message": "Course updated successfully!"})
    return redirect(url_for("super_admin.courses"))


# ------------------------------
# Delete Course
# ------------------------------
@superadmin_bp.route("/courses/delete/<int:course_id>", methods=["GET"])
def delete_course(course_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM courses WHERE course_id=%s", (course_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for("super_admin.courses"))


# ------------------------------
# Toggle Course Status (AJAX)
# ------------------------------
@superadmin_bp.route("/toggle_course_status/<int:course_id>", methods=["POST"])
def toggle_course_status(course_id):
    data = request.get_json()
    new_status = data.get("is_active")
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE courses SET is_active = %s WHERE course_id = %s", (new_status, course_id))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({"success": True})


@superadmin_bp.route('/assign_admin', methods=['GET'])
def assign_admin_page():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    
    # Get courses
    cursor.execute("SELECT course_id, course_name, assigned_admin_id FROM courses WHERE is_active=1")
    courses = cursor.fetchall()
    
    # Get admins
    cursor.execute("SELECT user_id, full_name FROM users WHERE role='admin' AND is_active=1")
    admins = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template('assign_admin.html', courses=courses, admins=admins)

# AJAX route to assign admin
@superadmin_bp.route('/assign_admin_ajax', methods=['POST'])
def assign_admin_ajax():
    data = request.get_json()
    course_id = data.get('course_id')
    admin_id = data.get('admin_id')
    
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("UPDATE courses SET assigned_admin_id=%s WHERE course_id=%s", (admin_id, course_id))
        conn.commit()
        response = {"status": "success", "message": "Admin assigned successfully!"}
    except Exception as e:
        response = {"status": "error", "message": str(e)}
    
    cursor.close()
    conn.close()
    return jsonify(response)

# ------------------------------
# Trainer Management
# ------------------------------
@superadmin_bp.route('/add_trainer', methods=['GET'])
def show_add_trainer():
    if session.get('user_role') != 'super_admin':
        return redirect(url_for('auth.login'))

    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT course_id, course_name FROM courses WHERE is_active=1")
        courses = cursor.fetchall()
        cursor.close()
        conn.close()
    except Exception as e:
        courses = []
        print("Error fetching courses:", e)

    return render_template('add_trainer.html', courses=courses)


@superadmin_bp.route('/add_trainer', methods=['POST'])
def add_trainer():
    if session.get("user_role") != "super_admin":
        return jsonify({"success": False, "error": "Unauthorized"}), 403

    full_name = request.form.get("full_name")
    email = request.form.get("email")
    phone = request.form.get("phone")
    role = request.form.get("role")
    is_active = request.form.get("is_active", 'True') == 'True'
    courses = request.form.getlist("courses")  # List of course_ids

    if not all([full_name, email]):
        return jsonify({"success": False, "error": "Missing required fields."})

    try:
        # Create trainer user
        user_id, plain_password = create_user(
            full_name=full_name,
            email=email,
            role=role,
            phone=phone,
            is_active=is_active
        )

        # Assign courses to trainer
        conn = get_connection()
        cursor = conn.cursor()
        for course_id in courses:
            cursor.execute("""
                INSERT INTO course_trainers (course_id, trainer_id)
                VALUES (%s, %s)
                ON DUPLICATE KEY UPDATE is_active=TRUE, assigned_date=CURRENT_DATE
            """, (course_id, user_id))
        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({
            "success": True,
            "user": {
                "user_id": user_id,
                "full_name": full_name,
                "email": email,
                "phone": phone,
                "role": role,
                "is_active": is_active,
                "password": plain_password
            }
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@superadmin_bp.route('/trainers')
def trainers():
    if session.get('user_role') != 'super_admin':
        return redirect(url_for('auth.login'))

    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '', type=str).strip()
    per_page = 10
    offset = (page - 1) * per_page

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    if search:
        search_like = f"%{search}%"
        cursor.execute("""
            SELECT user_id, full_name, email, phone, role, is_active
            FROM users
            WHERE role='trainer' AND full_name LIKE %s
            ORDER BY user_id DESC
            LIMIT %s OFFSET %s
        """, (search_like, per_page, offset))
        trainers = cursor.fetchall()
        cursor.execute("SELECT COUNT(*) AS total FROM users WHERE role='trainer' AND full_name LIKE %s", (search_like,))
    else:
        cursor.execute("""
            SELECT user_id, full_name, email, phone, role, is_active
            FROM users
            WHERE role='trainer'
            ORDER BY user_id DESC
            LIMIT %s OFFSET %s
        """, (per_page, offset))
        trainers = cursor.fetchall()
        cursor.execute("SELECT COUNT(*) AS total FROM users WHERE role='trainer'")
    total = cursor.fetchone()['total']

    # For each trainer, get assigned courses as a list of dicts
    for trainer in trainers:
        cursor.execute("""
            SELECT c.course_name
            FROM course_trainers ct
            JOIN courses c ON ct.course_id = c.course_id
            WHERE ct.trainer_id=%s AND ct.is_active=1
        """, (trainer['user_id'],))
        trainer['courses'] = cursor.fetchall()

    cursor.close()
    conn.close()

    total_pages = (total + per_page - 1) // per_page

    return render_template(
        'trainers.html',
        trainers=trainers,
        page=page,
        total_pages=total_pages,
        search=search
    )


# ------------------------------
# Edit Trainer (GET)
# ------------------------------
@superadmin_bp.route('/trainers/edit/<int:trainer_id>', methods=['GET'])
def edit_trainer(trainer_id):
    if session.get('user_role') != 'super_admin':
        return redirect(url_for('auth.login'))

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT user_id, full_name, email, phone, role, is_active FROM users WHERE user_id=%s AND role='trainer'", (trainer_id,))
    trainer = cursor.fetchone()
    cursor.execute("SELECT course_id, course_name FROM courses WHERE is_active=1")
    courses = cursor.fetchall()
    cursor.execute("SELECT course_id FROM course_trainers WHERE trainer_id=%s AND is_active=1", (trainer_id,))
    assigned_courses = [row['course_id'] for row in cursor.fetchall()]
    cursor.close()
    conn.close()

    if not trainer:
        return "Trainer not found", 404

    return render_template('edit_trainer.html', trainer=trainer, courses=courses, assigned_courses=assigned_courses)

# ------------------------------
# Edit Trainer (POST)
# ------------------------------
@superadmin_bp.route('/trainers/edit/<int:trainer_id>', methods=['POST'])
def update_trainer(trainer_id):
    if session.get('user_role') != 'super_admin':
        return redirect(url_for('auth.login'))

    full_name = request.form.get('full_name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    is_active = request.form.get('is_active', 'True') == 'True'
    courses = request.form.getlist('courses')

    if not all([full_name, email]):
        return "Missing required fields", 400

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE users SET full_name=%s, email=%s, phone=%s, is_active=%s
        WHERE user_id=%s AND role='trainer'
    """, (full_name, email, phone, is_active, trainer_id))

    # Remove all current course assignments
    cursor.execute("UPDATE course_trainers SET is_active=0 WHERE trainer_id=%s", (trainer_id,))
    # Assign selected courses
    for course_id in courses:
        cursor.execute("""
            INSERT INTO course_trainers (course_id, trainer_id, is_active, assigned_date)
            VALUES (%s, %s, TRUE, CURRENT_DATE)
            ON DUPLICATE KEY UPDATE is_active=TRUE, assigned_date=CURRENT_DATE
        """, (course_id, trainer_id))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for('super_admin.trainers'))

# ------------------------------
# Delete Trainer
# ------------------------------
@superadmin_bp.route('/trainers/delete/<int:trainer_id>', methods=['GET'])
def delete_trainer(trainer_id):
    if session.get('user_role') != 'super_admin':
        return redirect(url_for('auth.login'))

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM users WHERE user_id=%s AND role='trainer'", (trainer_id,))
    cursor.execute("UPDATE course_trainers SET is_active=0 WHERE trainer_id=%s", (trainer_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for('super_admin.trainers'))

# ------------------------------
# Assign Courses to Trainer (GET)
# ------------------------------
@superadmin_bp.route('/assign_courses', methods=['GET'])
def assign_courses_page():
    if session.get('user_role') != 'super_admin':
        return redirect(url_for('auth.login'))

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT user_id, full_name FROM users WHERE role='trainer' AND is_active=1")
    trainers = cursor.fetchall()
    cursor.execute("SELECT course_id, course_name FROM courses WHERE is_active=1")
    courses = cursor.fetchall()

    # Get current assignments for display
    for trainer in trainers:
        cursor.execute("""
            SELECT c.course_name FROM course_trainers ct
            JOIN courses c ON ct.course_id = c.course_id
            WHERE ct.trainer_id=%s AND ct.is_active=1
        """, (trainer['user_id'],))
        trainer['courses'] = cursor.fetchall()

    cursor.close()
    conn.close()
    return render_template('assign_courses.html', trainers=trainers, courses=courses)

# Assign Courses to Trainer (AJAX)
@superadmin_bp.route('/assign_courses_ajax', methods=['POST'])
def assign_courses_ajax():
    if session.get('user_role') != 'super_admin':
        return jsonify({"status": "error", "message": "Unauthorized"}), 403

    data = request.get_json()
    trainer_id = data.get('trainer_id')
    course_ids = data.get('course_ids', [])

    if not trainer_id or not course_ids:
        return jsonify({"status": "error", "message": "Missing trainer or courses."})

    conn = get_connection()
    cursor = conn.cursor()
    try:
        # Remove all current assignments
        cursor.execute("UPDATE course_trainers SET is_active=0 WHERE trainer_id=%s", (trainer_id,))
        # Assign selected courses
        for course_id in course_ids:
            cursor.execute("""
                INSERT INTO course_trainers (course_id, trainer_id, is_active, assigned_date)
                VALUES (%s, %s, TRUE, CURRENT_DATE)
                ON DUPLICATE KEY UPDATE is_active=TRUE, assigned_date=CURRENT_DATE
            """, (course_id, trainer_id))
        conn.commit()
        response = {"status": "success", "message": "Courses assigned successfully!"}
    except Exception as e:
        response = {"status": "error", "message": str(e)}
    cursor.close()
    conn.close()
    return jsonify(response)

@superadmin_bp.route('/admins/profile/<int:user_id>', methods=['GET'])
def view_admin_profile(user_id):
    if session.get("user_role") != "super_admin":
        return jsonify({"success": False, "error": "Unauthorized"}), 403
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT user_id, full_name, email, phone, role, is_active, created_at
            FROM users
            WHERE user_id = %s AND role = 'admin'
        """, (user_id,))
        admin = cursor.fetchone()
        cursor.close()
        conn.close()
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    if not admin:
        return jsonify({"success": False, "error": "Admin not found"}), 404
    return jsonify({"success": True, "admin": admin})
